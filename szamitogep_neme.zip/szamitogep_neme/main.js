console.log("%cA betűtípust sajnos nem tudtam eltalálni.", "background: red; color: yellow; font-size: x-large");
console.log("%cKészítette: Gyuris Dániel", "font-size: small");